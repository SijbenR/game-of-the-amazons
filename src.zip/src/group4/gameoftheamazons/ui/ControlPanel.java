package group4.gameoftheamazons.ui;

import javax.swing.*;
import java.awt.*;

public class ControlPanel extends JPanel {

    public ControlPanel(int sizeX, int sizeY) {
        setSize(sizeX, sizeY);
        setBackground(Color.white);
    }

}

