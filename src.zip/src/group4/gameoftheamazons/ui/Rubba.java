package group4.gameoftheamazons.ui;

import java.awt.*;

public class Rubba {

    int x = 0;
    int y = 0; // Current ball position
    int dx = 4; // Increment on ball's x-coordinate
    int dy = 4; // Increment on ball's y-coordinate
    int radius = 15; // Ball radius

    public Rubba(int x, int y) {
        this.x = x;
        this.y = y;
    }
    Color color = new Color((int) (Math.random() * 256),
            (int) (Math.random() * 256), (int) (Math.random() * 256));

    public void drawBall(Graphics g) {
        g.setColor(color);
        g.fillOval(x - radius, y - radius,
                radius * 2, radius * 2);
    }

    public void move() {
        x += dx;
        y += dy;
    }

}
