package group4.gameoftheamazons.ui;

public class GridCoordinate {

    public int x;
    public int y;

    public GridCoordinate(int x, int y) {
        this.x = x;
        this.y = y;
    }

}
