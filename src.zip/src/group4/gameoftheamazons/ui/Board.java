package group4.gameoftheamazons.ui;

import group4.gameoftheamazons.components.ImageLoader;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.util.ArrayList;

import static java.lang.Math.sqrt;

public class Board extends JPanel implements MouseMotionListener, MouseListener, ActionListener {

    private final Color LIGHT_BLUE = new Color(0, 0, 0, 150);
    private Shape square;

    private int index;
    private int xCor, yCor;
    private int counter1 = 0, counter2 = 0, counter3 = 0;
    private int gridXCor, gridYCor;

    Rubba rubba = new Rubba(50,50);

    public Image[] piece, letter, figure;
    public int x, y, dx, dy, speed, delay = 1000/60;
    Timer timer;

    private boolean setPath = false, setStart = false, setEnd = false, startAnimation = false;
    private boolean paintAll = false;
    private boolean DEBUG = false;

    private boolean stopTimer = false;

    public int sizeX;
    public int sizeY;
    public int width;
    public int height;

    ArrayList<Shape> cells = new ArrayList<>();
    ArrayList<GridCoordinate> pieceCoordinates = new ArrayList<>();
    ArrayList<Shape> nodes = new ArrayList<>();
    ArrayList<GridCoordinate> nodesCoordinates = new ArrayList<>();
    ArrayList<Shape> start = new ArrayList<>();
    ArrayList<GridCoordinate> startCoordinates = new ArrayList<>();
    ArrayList<Shape> end = new ArrayList<>();
    ArrayList<GridCoordinate> endCoordinates = new ArrayList<>();

    // Constructor
    public Board(int sizeX, int sizeY, int gridX, int gridY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;

        width = sizeX / gridX;
        height = sizeY / gridY;

        x = 1*width; y = 7*height;

        setSize(sizeX, sizeY);
        setBackground(Color.lightGray);
        addMouseListener(this);
        addMouseMotionListener(this);
    }

    // Sets the mode
    public void setMode(boolean setPath, boolean setStart, boolean setEnd, boolean startAnimation) {
        this.setPath = setPath;
        this.setStart = setStart;
        this.setEnd = setEnd;
        this.startAnimation = startAnimation;
        timer = new Timer(delay, this); System.out.println("New timer");
    }

    // Paint method
    public void paintComponent(Graphics g) {

        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Load Sprite Images
        try {
            piece = ImageLoader.loadImage("../images/pieces-2x.png", 2*60, 2*60);
            letter = ImageLoader.loadImage("../images/letters-2x.png", 2*60, 2*60);
            figure = ImageLoader.loadImage("../images/figures-2x.png", 2*60, 2*60);
        } catch (IOException e) {
            System.out.println("Error loading image");
        }

        drawCells(g2, width, height);
        //drawGrid(g2);

        g2.drawImage(piece[0], x, y, width, height, this);
        //drawPiece(g2, 0, 1, 7);
        drawPiece(g2, 0, 4, 10);
        drawPiece(g2, 0, 7, 10);
        drawPiece(g2, 0, 10, 7);
        drawPiece(g2, 1, 1, 4);
        drawPiece(g2, 1, 4, 1);
        drawPiece(g2, 1, 7, 1);
        drawPiece(g2, 1, 10, 4);
        drawPiece(g2, 2, 5, 5);

        //rubba.drawBall(g2);

        // Boardletters
        for (int i = 0; i < letter.length; i++) {
            g2.drawImage(letter[i], (i + 1) * width, 0 * height, width, height, this);
            g2.drawImage(letter[i], (i + 1) * width, (letter.length + 1) * height, width, height, this);
        }

        // Boardfigures
        for (int j = 0; j < figure.length; j++) {
            g2.drawImage(figure[j], 0 * width, (j + 1) * height, width, height, this);
            g2.drawImage(figure[j], (figure.length + 1) * width, (j + 1) * height, width, height, this);
        }

        if (startAnimation) {
            move(4,-4);
        }

        if (nodesCoordinates.size() > 0) {
            for (int i = 0; i < nodesCoordinates.size() - 1; i = i + 2) {
                g2.setPaint(Color.black);
                drawLine(g2, nodesCoordinates.get(i).x, nodesCoordinates.get(i).y, nodesCoordinates.get(i + 1).x, nodesCoordinates.get(i + 1).y);
            }
        }
        if (paintAll) {
            // Cells
            g2.setPaint(LIGHT_BLUE);
            //g2.fill(cells.get(index));
            // GridPointer
            Rectangle2D cellPointer = new Rectangle2D.Double(gridXCor*width, gridYCor*height, width, height);
            Rectangle2D gridPointer = new Rectangle2D.Double(gridXCor*width + width/2 - 4, gridYCor*height + height/2 - 4, 8, 8);
            g2.setPaint(LIGHT_BLUE);
            g2.fill(cellPointer);
            g2.fill(gridPointer);
            // LineIndicator
            if (nodesCoordinates.size() > 0 && (nodesCoordinates.size() - 1) % 2 == 0) {
                g2.setPaint(Color.black);
                drawLine(g2, nodesCoordinates.get(nodesCoordinates.size() - 1).x, nodesCoordinates.get(nodesCoordinates.size() - 1).y, gridXCor, gridYCor);
            }
            // Nodes
            g2.setPaint(Color.black);
            for (int i = 0; i < nodes.size(); i++) {
                g2.fill(nodes.get(i));
            }
            // Start
            g2.setPaint(Color.green);
            for (int i = 0; i < start.size(); i++) {
                g2.fill(start.get(i));
            }
            // End
            g2.setPaint(Color.red);
            for (int i = 0; i < end.size(); i++) {
                g2.fill(end.get(i));
            }
        }

    }

    public void move(int xEnd, int yEnd) {
        xEnd = xEnd; yEnd = yEnd;
        GridCoordinate point = new GridCoordinate(xEnd, yEnd);
        pieceCoordinates.add(point);
        timer.start();
        repaint();
        System.out.println("Start Animation");
        if (x <= 3) {
            speed = 3;
        }
        if (x > 3 && x <= 6) {
            speed = 2;
        }
        if (x > 6) {
            speed = 1;
        }
        dx = xEnd*speed; dy = yEnd*speed;
        x = x + dx; y = y + dy;
        System.out.println("x: " + x + ", y: " + y);
        if (x >= (pieceCoordinates.get(pieceCoordinates.size()-1).x + 1)*width) {
            timer.stop();
            startAnimation = false;
            System.out.println("Stop animation");
        }
    }

    public void actionPerformed(ActionEvent e) {
        repaint();
    }

    public void undo() {
        ArrayList<GridCoordinate> tempNodesCoordinates = new ArrayList<>();
        ArrayList<Shape> tempNodes = new ArrayList<>();
        ArrayList<Shape> tempStart = new ArrayList<>();
        ArrayList<Shape> tempEnd = new ArrayList<>();
        if (setPath) {
            for (int i = 0; i < nodesCoordinates.size() - 2; i++) {
                tempNodesCoordinates.add(nodesCoordinates.get(i));
            }
            for (int i = 0; i < nodes.size() - 2; i++) {
                tempNodes.add(nodes.get(i));
            }
            nodesCoordinates = tempNodesCoordinates;
            nodes = tempNodes;
        }
        if (setStart) {
            for (int i = 0; i < start.size() - 1; i++) {
                tempStart.add(start.get(i));
            }
            start = tempStart;
        }
        if (setEnd) {
            for (int i = 0; i < start.size() - 1; i++) {
                tempStart.add(start.get(i));
            }
            end = tempEnd;
        }
    }

    // Draws a line between two grid node coordinates
    public void drawLine(Graphics2D g, int gridX1, int gridY1, int gridX2, int gridY2) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.drawLine(gridX1 * width + width/2, gridY1 * width + height/2, gridX2 * width + width/2, gridY2 * width + height/2);
    }

    // Draws a piece on the board
    public void drawPiece(Graphics2D g, int index, int x, int y) {
        g.drawImage(piece[index], x*width, y*height, width, height, this);
    }

    // Draws the grid lines
    public void drawGrid(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        for (int i = 0; i < sizeX / width; i++) {
            Shape line = new Rectangle2D.Double((i + 1) * height, 0, 1, sizeY);
            g.setPaint(Color.lightGray);
            g.fill(line);
        }
        for (int j = 0; j < sizeY / width; j++) {
            Shape line = new Rectangle2D.Double(0, (j + 1) * height, sizeX, 1);
            g.setPaint(Color.lightGray);
            g.fill(line);
        }
    }

    // Draws the board grid
    public void drawCells(Graphics2D g, int width, int height) {
        Color color;
        Color even = new Color(209,140,72,255);
        Color odd = new Color(255,207,159,255);
        for (int i = 0; i < sizeX / width; i++) {
            for (int j = 0; j < sizeY / height; j++) {
                if (i >=1 & j>=1 & i < sizeX/width - 1 & j < sizeY/height - 1) {
                    if (i % 2 == 0) {
                        if (j % 2 == 0) {
                            color = even;
                        } else {
                            color = odd;
                        }
                    } else {
                        if (j % 2 != 0) {
                            color = even;
                        } else {
                            color = odd;
                        }
                    }
                    drawSquare(g, i * (width), j * (height), width, height, color);
                }
            }
        }
    }

    // Draws a square
    public void drawSquare(Graphics2D g, int x, int y, int width, int height, Color color) {
        square = new Rectangle2D.Double(x, y, width, height);
        cells.add(square);
        g.setPaint(color);
        g.fill(square);
    }

    // Mouse listener: when moved
    public void mouseMoved(MouseEvent e) {
        if (setPath || setStart || setEnd) {
            for (Shape r : cells) {
                if (r.contains(e.getPoint())) {
                    gridXCor = e.getX() / width;
                    gridYCor = e.getY() / height;
                    paintAll = true;
                    repaint();
                }
            }
        }
    }

    // Mouse listener: when button pressed
    public void mousePressed(MouseEvent e) {
        if (setPath) {
            xCor = e.getX();
            yCor = e.getY();
            GridCoordinate point = new GridCoordinate(gridXCor, gridYCor);
            nodesCoordinates.add(point);
            nodes.add(new Rectangle2D.Double(gridXCor * width - 4 + width/2, gridYCor * height - 4 + height/2, 8, 8));
            if (DEBUG) {
                System.out.println(counter1);
                for (int i = 0; i < counter1; i++) {
                    System.out.println("x: " + nodesCoordinates.get(i).x + ", y: " + nodesCoordinates.get(i).y);
                }
            }
            repaint();
            counter1++;
        }
        if (setStart) {
            if (start.size() < 1) {
                xCor = e.getX();
                yCor = e.getY();
                GridCoordinate point = new GridCoordinate(gridXCor, gridYCor);
                startCoordinates.add(point);
                start.add(new Rectangle2D.Double(gridXCor * width - 4, gridYCor * height - 4, 8, 8));
                if (DEBUG) {
                    System.out.println(counter2);
                    for (int i = 0; i < counter2; i++) {
                        System.out.println("x: " + startCoordinates.get(i).x + ", y: " + startCoordinates.get(i).y);
                    }
                }
                repaint();
                counter2++;
            }
        }
        if (setEnd) {
            if (end.size() < 1) {
                xCor = e.getX();
                yCor = e.getY();
                GridCoordinate point = new GridCoordinate(gridXCor, gridYCor);
                endCoordinates.add(point);
                end.add(new Rectangle2D.Double(gridXCor * width - 4, gridYCor * height - 4, 8, 8));
                if (DEBUG) {
                    System.out.println(counter3);
                    for (int i = 0; i < counter3; i++) {
                        System.out.println("x: " + endCoordinates.get(i).x + ", y: " + endCoordinates.get(i).y);
                    }
                }
                repaint();
                counter3++;
            }
        }
    }

    // Returns the content of the ArrayLists as a string
    public String toString() {
        String string = "";
        for (int i = 0; i < nodesCoordinates.size() - 1; i = i + 2) {
            string += "n" + " " + nodesCoordinates.get(i).x + " " + nodesCoordinates.get(i).y + " " + nodesCoordinates.get(i + 1).x + " " + nodesCoordinates.get(i + 1).y + "\n";
        }
        string += "s" + " " + startCoordinates.get(0).x + " " + startCoordinates.get(0).y + "\n";
        string += "e" + " " + endCoordinates.get(0).x + " " + endCoordinates.get(0).y + "\n";

        return string;
    }

    public void mouseClicked(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }

    public void mouseDragged(MouseEvent e) {

    }

}
