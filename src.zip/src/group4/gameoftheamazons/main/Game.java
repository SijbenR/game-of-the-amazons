package group4.gameoftheamazons.main;

import group4.gameoftheamazons.ui.Screen;

public class Game {

    public static void main(String[] args) {
        new Screen(700, 700, 10, 10);
    }

}
